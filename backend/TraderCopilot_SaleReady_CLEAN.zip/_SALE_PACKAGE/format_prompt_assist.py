from __future__ import annotations

def build_context(token: str) -> str:
    return f"Contexto base para {token.upper()}."
