El mecanismo de quema (EIP-1559) mantiene la oferta deflacionaria durante periodos de alta congestión.
---
Staking ratio sigue en aumento, reduciendo el supply flotante disponible para venta inmediata.
---
Divergencia positiva en direcciones activas diarias sugiere un repunte en la utilidad de la red base.
