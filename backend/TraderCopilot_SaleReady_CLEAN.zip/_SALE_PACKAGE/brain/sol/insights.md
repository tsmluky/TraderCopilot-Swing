Se ha detectado una divergencia alcista en el CVD de Spot vs Futuros, indicando compra genuina.
---
Las métricas On-Chain muestran una salida neta de exchanges significativa en las últimas 48h.
---
La estructura de mercado en marcos temporales altos (HTF) sugiere una continuación de la tendencia principal tras la consolidación actual.
