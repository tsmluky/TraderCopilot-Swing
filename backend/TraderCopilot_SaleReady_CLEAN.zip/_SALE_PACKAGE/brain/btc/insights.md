El supply de BTC en exchanges ha alcanzado mínimos de 5 años, creando un shock de oferta potencial.
---
Análisis de UTXO muestra que los HODLers de largo plazo no están vendiendo en esta corrección.
---
La liquidez en el orderbook muestra una fuerte demanda ("Buy Wall") protegiendo los niveles clave de soporte.
