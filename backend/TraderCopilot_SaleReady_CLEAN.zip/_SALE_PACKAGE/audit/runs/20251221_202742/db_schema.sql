
CREATE TABLE users (
	id INTEGER NOT NULL, 
	email VARCHAR, 
	name VARCHAR, 
	hashed_password VARCHAR, 
	role VARCHAR, 
	"plan" VARCHAR, 
	plan_status VARCHAR, 
	plan_expires_at DATETIME, 
	telegram_chat_id VARCHAR, 
	timezone VARCHAR, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (email)
)

;

CREATE TABLE push_subscriptions (
	id INTEGER NOT NULL, 
	endpoint VARCHAR, 
	p256dh VARCHAR, 
	auth VARCHAR, 
	created_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (endpoint)
)

;

CREATE TABLE scheduler_lock (
	lock_name VARCHAR NOT NULL, 
	owner_id VARCHAR, 
	expires_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (lock_name)
)

;

CREATE TABLE signals (
	id INTEGER NOT NULL, 
	timestamp DATETIME, 
	token VARCHAR, 
	timeframe VARCHAR, 
	direction VARCHAR, 
	entry FLOAT, 
	tp FLOAT, 
	sl FLOAT, 
	confidence FLOAT, 
	rationale TEXT, 
	source VARCHAR, 
	mode VARCHAR, 
	raw_response TEXT, 
	strategy_id VARCHAR, 
	user_id INTEGER, 
	idempotency_key VARCHAR, 
	is_hidden INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)

;
CREATE UNIQUE INDEX ix_signals_idempotency_key ON signals (idempotency_key);

CREATE TABLE strategy_configs (
	id INTEGER NOT NULL, 
	strategy_id VARCHAR, 
	persona_id VARCHAR, 
	name VARCHAR, 
	description TEXT, 
	version VARCHAR, 
	user_id INTEGER, 
	is_public INTEGER, 
	color VARCHAR, 
	icon VARCHAR, 
	expected_roi VARCHAR, 
	enabled INTEGER, 
	interval_seconds INTEGER, 
	tokens VARCHAR, 
	timeframes VARCHAR, 
	risk_profile VARCHAR, 
	mode VARCHAR, 
	source_type VARCHAR, 
	total_signals INTEGER, 
	win_rate FLOAT, 
	avg_confidence FLOAT, 
	last_execution DATETIME, 
	config_json TEXT, 
	created_at DATETIME, 
	updated_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (persona_id), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)

;

CREATE TABLE admin_audit_logs (
	id INTEGER NOT NULL, 
	admin_id INTEGER, 
	action VARCHAR, 
	target_id VARCHAR, 
	details TEXT, 
	ip_address VARCHAR, 
	timestamp DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(admin_id) REFERENCES users (id)
)

;

CREATE TABLE daily_usage (
	id INTEGER NOT NULL, 
	user_id INTEGER, 
	feature VARCHAR, 
	date VARCHAR, 
	count INTEGER, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_user_feature_date UNIQUE (user_id, feature, date), 
	FOREIGN KEY(user_id) REFERENCES users (id)
)

;

CREATE TABLE signal_evaluations (
	id INTEGER NOT NULL, 
	signal_id INTEGER, 
	evaluated_at DATETIME, 
	result VARCHAR, 
	pnl_r FLOAT, 
	exit_price FLOAT, 
	PRIMARY KEY (id), 
	FOREIGN KEY(signal_id) REFERENCES signals (id)
)

;
